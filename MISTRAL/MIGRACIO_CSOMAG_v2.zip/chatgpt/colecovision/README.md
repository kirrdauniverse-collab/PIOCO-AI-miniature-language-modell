# colecovision — chatgpt port

Reserved workspace for the **chatgpt** model's port to **colecovision**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
