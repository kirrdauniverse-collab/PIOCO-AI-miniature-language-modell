# atari-falcon — chatgpt port

Reserved workspace for the **chatgpt** model's port to **atari-falcon**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
