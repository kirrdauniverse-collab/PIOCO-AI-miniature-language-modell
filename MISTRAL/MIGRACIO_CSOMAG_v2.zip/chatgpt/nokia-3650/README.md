# nokia-3650 — chatgpt port

Reserved workspace for the **chatgpt** model's port to **nokia-3650**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
