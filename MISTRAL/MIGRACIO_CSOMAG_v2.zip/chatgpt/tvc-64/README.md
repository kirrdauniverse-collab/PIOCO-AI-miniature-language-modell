# tvc-64 — chatgpt port

Reserved workspace for the **chatgpt** model's port to **tvc-64**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
