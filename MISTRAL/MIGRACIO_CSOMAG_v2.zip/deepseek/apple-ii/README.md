# apple-ii — deepseek port

Reserved workspace for the **deepseek** model's port to **apple-ii**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
