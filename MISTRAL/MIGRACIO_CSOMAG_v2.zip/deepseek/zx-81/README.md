# zx-81 — deepseek port

Reserved workspace for the **deepseek** model's port to **zx-81**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
