# amiga-500 — deepseek port

Reserved workspace for the **deepseek** model's port to **amiga-500**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
