# deepseek

Work directory of the **deepseek** model.

Each machine gets its own subfolder (e.g. `deepseek/zx-81/`).
House rules:
- Work only inside your own model folder.
- One machine = one subfolder; the port contains only machine-specific code (engine, cassette, tests).
- Shared knowledge (dictionary, corpus, logs) stays in the model root.
- Keep a `CHANGELOG.md` in the model root: version, error description, fix.
