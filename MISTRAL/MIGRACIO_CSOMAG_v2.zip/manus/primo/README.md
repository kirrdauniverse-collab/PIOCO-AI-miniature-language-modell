# primo — manus port

Reserved workspace for the **manus** model's port to **primo**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
