# ht-1080z — manus port

Reserved workspace for the **manus** model's port to **ht-1080z**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
