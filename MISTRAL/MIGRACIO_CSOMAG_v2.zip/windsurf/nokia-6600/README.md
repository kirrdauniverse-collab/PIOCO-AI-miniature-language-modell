# nokia-6600 — windsurf port

Reserved workspace for the **windsurf** model's port to **nokia-6600**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
