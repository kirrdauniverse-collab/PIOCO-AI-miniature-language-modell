# nintendo-nes — mistral port

Reserved workspace for the **mistral** model's port to **nintendo-nes**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
