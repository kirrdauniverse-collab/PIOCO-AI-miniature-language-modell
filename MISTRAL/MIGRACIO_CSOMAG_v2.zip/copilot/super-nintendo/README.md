# super-nintendo — copilot port

Reserved workspace for the **copilot** model's port to **super-nintendo**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
