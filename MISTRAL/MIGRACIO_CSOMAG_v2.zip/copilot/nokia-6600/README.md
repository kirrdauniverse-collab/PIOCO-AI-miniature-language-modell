# nokia-6600 — copilot port

Reserved workspace for the **copilot** model's port to **nokia-6600**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
