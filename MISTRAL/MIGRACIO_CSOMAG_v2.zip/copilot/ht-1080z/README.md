# ht-1080z — copilot port

Reserved workspace for the **copilot** model's port to **ht-1080z**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
