# nintendo-nes — copilot port

Reserved workspace for the **copilot** model's port to **nintendo-nes**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
