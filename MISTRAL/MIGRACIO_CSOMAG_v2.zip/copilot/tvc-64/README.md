# tvc-64 — copilot port

Reserved workspace for the **copilot** model's port to **tvc-64**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
