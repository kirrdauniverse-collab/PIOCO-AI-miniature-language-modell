# primo — grok port

Reserved workspace for the **grok** model's port to **primo**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
