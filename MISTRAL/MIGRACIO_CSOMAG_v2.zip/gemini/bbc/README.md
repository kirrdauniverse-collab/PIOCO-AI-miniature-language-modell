# bbc — gemini port

Reserved workspace for the **gemini** model's port to **bbc**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
