# playstation-2 — gemini port

Reserved workspace for the **gemini** model's port to **playstation-2**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
