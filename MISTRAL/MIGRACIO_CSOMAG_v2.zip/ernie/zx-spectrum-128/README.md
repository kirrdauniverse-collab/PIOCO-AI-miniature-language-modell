# zx-spectrum-128 — ernie port

Reserved workspace for the **ernie** model's port to **zx-spectrum-128**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
