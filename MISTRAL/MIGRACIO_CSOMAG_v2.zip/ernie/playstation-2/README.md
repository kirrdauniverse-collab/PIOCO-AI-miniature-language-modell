# playstation-2 — ernie port

Reserved workspace for the **ernie** model's port to **playstation-2**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
