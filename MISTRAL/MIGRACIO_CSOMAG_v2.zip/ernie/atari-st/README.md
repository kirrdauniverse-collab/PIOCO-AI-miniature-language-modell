# atari-st — ernie port

Reserved workspace for the **ernie** model's port to **atari-st**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
