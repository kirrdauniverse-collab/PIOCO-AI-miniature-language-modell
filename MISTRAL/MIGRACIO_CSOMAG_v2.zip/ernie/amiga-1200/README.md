# amiga-1200 — ernie port

Reserved workspace for the **ernie** model's port to **amiga-1200**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
