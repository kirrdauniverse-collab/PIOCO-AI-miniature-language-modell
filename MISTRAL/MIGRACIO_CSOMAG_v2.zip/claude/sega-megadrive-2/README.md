# sega-megadrive-2 — claude port

Reserved workspace for the **claude** model's port to **sega-megadrive-2**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
