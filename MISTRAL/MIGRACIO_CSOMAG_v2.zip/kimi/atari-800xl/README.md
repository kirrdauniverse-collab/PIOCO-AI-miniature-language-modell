# atari-800xl — kimi port

Reserved workspace for the **kimi** model's port to **atari-800xl**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
