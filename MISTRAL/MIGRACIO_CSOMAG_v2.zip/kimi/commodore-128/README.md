# commodore-128 — kimi port

Reserved workspace for the **kimi** model's port to **commodore-128**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
