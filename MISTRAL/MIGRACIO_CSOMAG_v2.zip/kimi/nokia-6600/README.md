# nokia-6600 — kimi port

Reserved workspace for the **kimi** model's port to **nokia-6600**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
