# zx-spectrum — kimi port

Reserved workspace for the **kimi** model's port to **zx-spectrum**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
