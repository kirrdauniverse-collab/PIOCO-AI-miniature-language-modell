# ht-1080z — qwen port

Reserved workspace for the **qwen** model's port to **ht-1080z**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
