# amiga-500 — opencode port

Reserved workspace for the **opencode** model's port to **amiga-500**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
