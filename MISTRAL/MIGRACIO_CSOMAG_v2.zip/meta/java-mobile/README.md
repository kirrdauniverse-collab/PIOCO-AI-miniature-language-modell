# java-mobile — meta port

Reserved workspace for the **meta** model's port to **java-mobile**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
