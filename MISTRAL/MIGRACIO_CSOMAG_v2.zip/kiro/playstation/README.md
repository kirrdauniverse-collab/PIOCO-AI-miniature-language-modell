# playstation — kiro port

Reserved workspace for the **kiro** model's port to **playstation**.
No port yet. When work starts, put the sources, build tools, tests and cassette/tape files here.
